<h1>Cadastrar Laboratorio</h1>
<form action="?page=sala-salvar" method="POST">
	<input type="hidden" name="acao" value="cadastrar">
	<div class="mb-3">
		<label>Numero da sala</label>
		<input type="text" name="numero_sala" class="form-control">
	</div>
	<div class="mb-3">
		<button type="submit" class="btn btn-success">Enviar</button>
	</div>
</form>